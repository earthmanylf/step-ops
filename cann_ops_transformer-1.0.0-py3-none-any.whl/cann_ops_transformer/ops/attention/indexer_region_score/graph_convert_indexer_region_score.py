"""TorchAir converter for IndexerRegionScore."""

try:
    import torch
    import torchair
    from torchair._ge_concrete_graph.fx2ge_converter import register_fx_node_ge_converter
    from torchair.ge import attr
    from torchair.ge._ge_graph import Tensor, TensorSpec
    from typing import List, Optional

    _TORCHAIR_AVAILABLE = True
except ImportError:
    _TORCHAIR_AVAILABLE = False


if _TORCHAIR_AVAILABLE:

    @register_fx_node_ge_converter(
        torch.ops.cann_ops_transformer.indexer_region_score.default
    )
    def convert_indexer_region_score(
        query: Tensor,
        weights: Tensor,
        *,
        key_summary: Optional[Tensor] = None,
        actual_kv_lengths: Optional[Tensor] = None,
        paged_key_summary: Optional[Tensor] = None,
        block_table: Optional[Tensor] = None,
        cu_seq_lens: Optional[Tensor] = None,
        mask_mode: int = 0,
        head_scale: float = 1.0,
        cache_mode: int = 0,
        max_region_len: int = -1,
        region_size: int = 8,
        top_k: int = 0,
        sort_mode: int = 1,
        out: Optional[Tensor] = None,
        selected_region_ids: Optional[Tensor] = None,
        meta_outputs: List[TensorSpec] = None,
    ):
        del meta_outputs
        if out is not None:
            raise RuntimeError(
                "TorchAir graph mode does not support a caller-provided out tensor; "
                "omit out so IndexerRegionScore owns its graph output."
            )
        if selected_region_ids is not None:
            raise RuntimeError(
                "TorchAir graph mode does not support caller-provided selected_region_ids; "
                "omit selected_region_ids so IndexerRegionScore owns its graph output."
            )
        score, selected = torchair.ge.custom_op(
            "IndexerRegionScore",
            inputs={
                "query": query,
                "weights": weights,
                "key_summary": key_summary,
                "actual_kv_lengths": actual_kv_lengths,
                "paged_key_summary": paged_key_summary,
                "block_table": block_table,
                "cu_seq_lens": cu_seq_lens,
            },
            attrs={
                "mask_mode": attr.Int(mask_mode),
                "head_scale": attr.Float(head_scale),
                "cache_mode": attr.Int(cache_mode),
                "max_region_len": attr.Int(max_region_len),
                "region_size": attr.Int(region_size),
                "top_k": attr.Int(top_k),
                "sort_mode": attr.Int(sort_mode),
            },
            outputs=["output", "selected_region_ids"],
        )
        return score, selected if top_k > 0 else None
