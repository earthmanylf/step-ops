"""PyTorch eager registration for IndexerRegionScore."""

from typing import Optional, Tuple

import torch
from torch.library import impl

from cann_ops_transformer.op_builder import OpBuilder, get_as_library


class IndexerRegionScoreOpBuilder(OpBuilder):
    def __init__(self):
        super().__init__("indexer_region_score", category="attention")

    def sources(self):
        return ["csrc/attention/indexer_region_score.cpp"]

    def schema(self) -> str:
        return (
            "indexer_region_score(Tensor query, Tensor weights, *, "
            "Tensor? key_summary=None, Tensor? actual_kv_lengths=None, "
            "Tensor? paged_key_summary=None, Tensor? block_table=None, "
            "Tensor? cu_seq_lens=None, int mask_mode=0, "
            "float head_scale=1.0, "
            "int cache_mode=0, int max_region_len=-1, int region_size=8, "
            "int top_k=0, int sort_mode=1, Tensor(a!)? out=None, "
            "Tensor(b!)? selected_region_ids=None) -> (Tensor(a!), Tensor(b!)?)"
        )

    def register_meta(self):
        @impl(get_as_library(), self.name, "Meta")
        def indexer_region_score_meta(
            query,
            weights,
            *,
            key_summary=None,
            actual_kv_lengths=None,
            paged_key_summary=None,
            block_table=None,
            cu_seq_lens=None,
            mask_mode=0,
            head_scale=1.0,
            cache_mode=0,
            max_region_len=-1,
            region_size=8,
            top_k=0,
            sort_mode=1,
            out=None,
            selected_region_ids=None,
        ):
            del weights, actual_kv_lengths, block_table, cu_seq_lens
            del mask_mode, head_scale, region_size
            if query.dim() != 4 or not (query.shape[1] == 1 or
                                          (query.shape[1] > 0 and query.shape[1] % 4 == 0)):
                raise RuntimeError("query must have shape [T,G,H,256] with G=1 or a positive multiple of 4")
            if cache_mode == 0:
                if key_summary is None:
                    raise RuntimeError("cache_mode=0 requires key_summary")
                seq_q, groups = query.shape[0], query.shape[1]
                if max_region_len < -1 or max_region_len > key_summary.shape[0]:
                    raise RuntimeError("cache_mode=0 requires -1 <= max_region_len <= key_summary.shape[0]")
                regions = key_summary.shape[0] if max_region_len == -1 else max_region_len
            elif cache_mode == 1:
                if paged_key_summary is None:
                    raise RuntimeError("cache_mode=1 requires paged_key_summary")
                if max_region_len < 0:
                    raise RuntimeError("cache_mode=1 requires max_region_len >= 0")
                seq_q, groups, regions = query.shape[0], query.shape[1], max_region_len
            else:
                raise RuntimeError(f"cache_mode must be 0 or 1, got {cache_mode}")
            if out is not None:
                if out.dim() != 3 or out.shape[0] != groups or out.shape[1] != seq_q or out.shape[2] < regions:
                    raise RuntimeError("out must have shape [G,T,R_out] with R_out >= max_region_len")
                score = out
            else:
                score = query.new_empty((groups, seq_q, regions), dtype=torch.float32)
            if top_k < 0 or sort_mode not in (0, 1):
                raise RuntimeError("top_k must be non-negative and sort_mode must be 0 or 1")
            if top_k == 0:
                if selected_region_ids is not None:
                    raise RuntimeError("selected_region_ids must be omitted when top_k is 0")
            elif selected_region_ids is None:
                selected_region_ids = query.new_empty((groups, seq_q, top_k), dtype=torch.int32)
            elif (selected_region_ids.dtype != torch.int32 or
                  tuple(selected_region_ids.shape) != (groups, seq_q, top_k)):
                raise RuntimeError("selected_region_ids must be INT32 [G,T,top_k]")
            return score, selected_region_ids


indexer_region_score_op_builder = IndexerRegionScoreOpBuilder()
indexer_region_score_op_builder._ensure_initialized()


@impl(get_as_library(), indexer_region_score_op_builder.name, "PrivateUse1")
def indexer_region_score(
    query: torch.Tensor,
    weights: torch.Tensor,
    *,
    key_summary: Optional[torch.Tensor] = None,
    actual_kv_lengths: Optional[torch.Tensor] = None,
    paged_key_summary: Optional[torch.Tensor] = None,
    block_table: Optional[torch.Tensor] = None,
    cu_seq_lens: Optional[torch.Tensor] = None,
    mask_mode: int = 0,
    head_scale: float = 1.0,
    cache_mode: int = 0,
    max_region_len: int = -1,
    region_size: int = 8,
    top_k: int = 0,
    sort_mode: int = 1,
    out: Optional[torch.Tensor] = None,
    selected_region_ids: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    """Score [T,G,H,D] queries; actual_kv_lengths holds effective KV sequence lengths including the current queries.

    For mask_mode=3, token j in request i is at
    actual_kv_lengths[i] - (cu_seq_lens[i+1] - cu_seq_lens[i]) + j.
    Without cu_seq_lens, continuous mode uses one request containing all T queries.
    With top_k=0, masked scores and columns beyond max_region_len are -inf.
    With top_k>0, only visible candidate scores are guaranteed; masked scores and
    output-tail columns are unspecified and must not be consumed. Selected IDs
    retain their ordering and use -1 for missing candidates.
    Always returns (score, ids). With top_k=0, ids is None. Otherwise omitted
    selected_region_ids is allocated as int32 [G,T,top_k] on query.device; a
    supplied tensor is reused and returned.
    """
    module = indexer_region_score_op_builder.load()
    return module.indexer_region_score(
        query,
        weights,
        key_summary,
        actual_kv_lengths,
        paged_key_summary,
        block_table,
        cu_seq_lens,
        mask_mode,
        head_scale,
        cache_mode,
        max_region_len,
        region_size,
        top_k,
        sort_mode,
        out,
        selected_region_ids,
    )
