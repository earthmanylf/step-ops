/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * Licensed under CANN Open Software License Agreement Version 2.0.
 */

#include <torch/extension.h>

#include <tuple>
#include <utility>

#include "aclnn_common.h"

namespace op_api {
namespace {
constexpr int64_t kHeadsPerGroupMin = 4;
constexpr int64_t kHeadsPerGroupMax = 128;
constexpr int64_t kHeadsPerGroupAlign = 4;
constexpr int64_t kProxyDim = 256;

bool IsDefined(const c10::optional<at::Tensor> &tensor)
{
    return tensor.has_value() && tensor.value().defined();
}

bool IsWeightDtypeSupported(const at::Tensor &weights)
{
    return weights.scalar_type() == at::kHalf || weights.scalar_type() == at::kBFloat16 ||
           weights.scalar_type() == at::kFloat;
}

void CheckCommon(const at::Tensor &query, const at::Tensor &weights,
                 const c10::optional<at::Tensor> &actualKvLengths, int64_t maskMode, int64_t regionSize)
{
    TORCH_CHECK(query.defined() && weights.defined(), "query and weights must be defined");
    TORCH_CHECK(query.dim() == 4, "query must be rank 4");
    TORCH_CHECK(weights.dim() == 3, "weights must be rank 3");
    TORCH_CHECK(IsWeightDtypeSupported(weights), "weights must be float16, bfloat16 or float32");
    TORCH_CHECK(query.scalar_type() == at::kFloat8_e4m3fn, "query must be float8_e4m3fn");
    TORCH_CHECK(maskMode == 0 || maskMode == 3, "mask_mode must be 0 or 3");
    TORCH_CHECK(query.size(1) == 1 || (query.size(1) > 0 && query.size(1) % 4 == 0),
                "query group count G must be 1 or a positive multiple of 4");
    const int64_t heads = query.size(2);
    TORCH_CHECK(heads >= kHeadsPerGroupMin && heads <= kHeadsPerGroupMax &&
                    heads % kHeadsPerGroupAlign == 0 && query.size(3) == kProxyDim,
                "query must have 4 <= H <= 128, H divisible by 4, and D=256");
    TORCH_CHECK(regionSize > 0, "region_size must be positive");
    if (maskMode == 3) {
        TORCH_CHECK(IsDefined(actualKvLengths), "mask_mode=3 requires actual_kv_lengths");
    }
}

std::pair<int64_t, int64_t> CheckContinuous(
    const at::Tensor &query, const at::Tensor &weights, const c10::optional<at::Tensor> &keySummary,
    const c10::optional<at::Tensor> &pagedKeySummary, const c10::optional<at::Tensor> &blockTable,
    const c10::optional<at::Tensor> &cuSeqLens)
{
    TORCH_CHECK(IsDefined(keySummary), "cache_mode=0 requires key_summary");
    TORCH_CHECK(!IsDefined(pagedKeySummary) && !IsDefined(blockTable),
                "cache_mode=0 does not accept paged-cache inputs");
    const auto &keySummaryTensor = keySummary.value();
    TORCH_CHECK(keySummaryTensor.dim() == 3 && keySummaryTensor.size(1) == 1 && keySummaryTensor.size(2) == kProxyDim,
                "key_summary must have shape [R,1,256]");
    TORCH_CHECK(keySummaryTensor.scalar_type() == at::kFloat8_e4m3fn, "key_summary must be float8_e4m3fn");
    TORCH_CHECK(weights.size(0) == query.size(0) && weights.size(1) == query.size(1) &&
                    weights.size(2) == query.size(2),
                "cache_mode=0 weights must have shape [T,G,H]");
    if (IsDefined(cuSeqLens)) {
        const auto &offsets = cuSeqLens.value();
        TORCH_CHECK(offsets.dim() == 1 && offsets.scalar_type() == at::kInt && offsets.size(0) >= 2,
                    "cu_seq_lens must be an int32 rank-1 tensor with at least two elements");
    }
    return {query.size(1), query.size(0)};
}

std::pair<int64_t, int64_t> CheckPaged(
    const at::Tensor &query, const at::Tensor &weights, const c10::optional<at::Tensor> &keySummary,
    const c10::optional<at::Tensor> &pagedKeySummary, const c10::optional<at::Tensor> &blockTable,
    const c10::optional<at::Tensor> &cuSeqLens, int64_t maxRegionLen)
{
    TORCH_CHECK(!IsDefined(keySummary), "cache_mode=1 does not accept key_summary");
    TORCH_CHECK(IsDefined(pagedKeySummary) && IsDefined(blockTable) && IsDefined(cuSeqLens),
                "cache_mode=1 requires paged_key_summary, block_table and cu_seq_lens");
    const auto &cache = pagedKeySummary.value();
    const auto &table = blockTable.value();
    const auto &offsets = cuSeqLens.value();
    TORCH_CHECK(cache.dim() == 4 && cache.size(2) == 1 && cache.size(3) == kProxyDim,
                "paged_key_summary must have shape [P,S,1,256]");
    TORCH_CHECK(cache.scalar_type() == at::kFloat8_e4m3fn, "paged_key_summary must be float8_e4m3fn");
    TORCH_CHECK(table.dim() == 2 && table.scalar_type() == at::kInt,
                "block_table must be a rank-2 int32 tensor");
    TORCH_CHECK(offsets.dim() == 1 && offsets.scalar_type() == at::kInt,
                "cu_seq_lens must be a rank-1 int32 tensor");
    TORCH_CHECK(offsets.size(0) == table.size(0) + 1,
                "cu_seq_lens length must equal block_table.shape[0] + 1");
    TORCH_CHECK(weights.size(0) == query.size(0) && weights.size(1) == query.size(1) &&
                    weights.size(2) == query.size(2),
                "cache_mode=1 weights must have shape [T,G,H]");
    TORCH_CHECK(maxRegionLen >= 0, "cache_mode=1 requires max_region_len >= 0");
    return {query.size(1), query.size(0)};
}
} // namespace

std::tuple<at::Tensor, c10::optional<at::Tensor>> indexer_region_score(
    const at::Tensor &query, const at::Tensor &weights, const c10::optional<at::Tensor> &keySummary,
    const c10::optional<at::Tensor> &actualKvLengths, const c10::optional<at::Tensor> &pagedKeySummary,
    const c10::optional<at::Tensor> &blockTable, const c10::optional<at::Tensor> &cuSeqLens,
    int64_t maskMode, double headScale, int64_t cacheMode, int64_t maxRegionLen, int64_t regionSize,
    int64_t topK, int64_t sortMode, const c10::optional<at::Tensor> &out,
    const c10::optional<at::Tensor> &selectedRegionIds)
{
    CheckCommon(query, weights, actualKvLengths, maskMode, regionSize);
    std::pair<int64_t, int64_t> dimensions;
    int64_t minRegions = maxRegionLen;
    int64_t requestCount = 1;
    if (cacheMode == 0) {
        dimensions = CheckContinuous(query, weights, keySummary, pagedKeySummary, blockTable, cuSeqLens);
        const int64_t keyRegions = keySummary.value().size(0);
        TORCH_CHECK(maxRegionLen >= -1 && maxRegionLen <= keyRegions,
                    "cache_mode=0 requires -1 <= max_region_len <= key_summary.shape[0]");
        minRegions = maxRegionLen == -1 ? keyRegions : maxRegionLen;
        if (IsDefined(cuSeqLens)) {
            requestCount = cuSeqLens.value().size(0) - 1;
        }
    } else if (cacheMode == 1) {
        dimensions = CheckPaged(query, weights, keySummary, pagedKeySummary, blockTable, cuSeqLens, maxRegionLen);
        requestCount = blockTable.value().size(0);
    } else {
        TORCH_CHECK(false, "cache_mode must be 0 or 1, got ", cacheMode);
    }

    if (maskMode == 3) {
        TORCH_CHECK(actualKvLengths.value().scalar_type() == at::kInt && actualKvLengths.value().dim() == 1 &&
                        actualKvLengths.value().size(0) == requestCount,
                    "actual_kv_lengths must be int32 [N]");
    }

    TORCH_CHECK(topK >= 0, "top_k must be non-negative");
    TORCH_CHECK(sortMode == 0 || sortMode == 1,
                "sort_mode must be 0 (score descending) or 1 (logical ID ascending)");

    const c10::OptionalDeviceGuard deviceGuard(query.device());
    at::Tensor output;
    if (IsDefined(out)) {
        output = out.value();
        TORCH_CHECK(output.scalar_type() == at::kFloat && output.dim() == 3 &&
                        output.size(0) == dimensions.first && output.size(1) == dimensions.second &&
                        output.size(2) >= minRegions,
                    "out must be FLOAT [G,T,R_out] with R_out >= max_region_len");
    } else {
        output = at::empty({dimensions.first, dimensions.second, minRegions}, query.options().dtype(at::kFloat));
    }
    c10::optional<at::Tensor> selectedOutput = c10::nullopt;
    if (topK == 0) {
        TORCH_CHECK(!IsDefined(selectedRegionIds),
                    "selected_region_ids must be omitted when top_k is 0");
    } else if (IsDefined(selectedRegionIds)) {
        selectedOutput = selectedRegionIds.value();
        const auto &ids = selectedOutput.value();
        TORCH_CHECK(ids.scalar_type() == at::kInt && ids.dim() == 3 &&
                        ids.size(0) == dimensions.first && ids.size(1) == dimensions.second &&
                        ids.size(2) == topK,
                    "selected_region_ids must be int32 [G,T,top_k]");
    } else {
        selectedOutput = at::empty({dimensions.first, dimensions.second, topK}, query.options().dtype(at::kInt));
    }
    ACLNN_CMD(aclnnIndexerRegionScore, query, weights, keySummary, actualKvLengths, pagedKeySummary, blockTable, cuSeqLens,
              maskMode, headScale, cacheMode, minRegions, regionSize, topK, sortMode,
              output, selectedOutput);
    return std::make_tuple(output, selectedOutput);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module)
{
    module.def("indexer_region_score", &indexer_region_score, "indexer_region_score");
}
} // namespace op_api
