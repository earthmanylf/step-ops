/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
**/

/*!
 * \file quant_reduce_scatter.cpp
 * \brief
 */
#include <torch/extension.h>
#include "aclnn_common.h"

namespace op_api {
// worldSize
const std::set<int> SUPPORT_WORLD_SIZE_LIST{2, 4, 8};
// x valid dtype
const std::set<int64_t> SUPPORT_X_DTYPE_LIST{aclDataType::ACL_INT8,        aclDataType::ACL_HIFLOAT8,
                                             aclDataType::ACL_FLOAT8_E5M2, aclDataType::ACL_FLOAT8_E4M3FN,
                                             aclDataType::ACL_FLOAT4_E1M2, aclDataType::ACL_FLOAT4_E2M1};
// scales valid dtype
const std::set<int64_t> SUPPORT_SCALES_DTYPE_LIST{aclDataType::ACL_FLOAT, aclDataType::ACL_FLOAT8_E8M0};

static const int H_LOWER_LIMIT = 1024;
static const int H_UPPER_LIMIT = 8192;
static const int NUM_64 = 64;
static const int NUM_128 = 128;
static const int DIM_ZERO = 0;
static const int DIM_ONE = 1;
static const int DIM_TWO = 2;
static const int DIM_THREE = 3;
static const int DIM_FOUR = 4;

inline TensorWrapper make_wrapper(const at::Tensor &tensor, aclDataType tensorAcltype)
{
    return {tensor, tensorAcltype};
}

inline bool CheckTensorNotEmpty(const at::Tensor &tensor)
{
    bool check_result = tensor.dim() > 0;
    for (int i = 0; i < tensor.dim(); ++i) {
        check_result &= (tensor.size(i) != 0);
    }
    return check_result;
}

at::Tensor NpuQuantReduceScatter(const at::Tensor &context, const at::Tensor &x, const at::Tensor &scales,
                                 int64_t hcclBufferSize, int64_t worldSize, c10::optional<std::string> reduceOp,
                                 c10::optional<int64_t> outputDtype, c10::optional<int64_t> xDtype,
                                 c10::optional<int64_t> scalesDtype)
{
    // 校验空tensor
    TORCH_CHECK(x.defined(), "The input tensor x can not be None.");
    TORCH_CHECK(scales.defined(), "The input tensor scales can not be None.");
    // 校验x的shape, 2维或者3维
    TORCH_CHECK(x.dim() == DIM_TWO || x.dim() == DIM_THREE,
                "The input x tensor shape is required to be 2 or 3 dim, but the actual input shape is ", x.dim());
    // 校验x是否为空tensor
    TORCH_CHECK(CheckTensorNotEmpty(x), "The input tensor x can not be empty tensor");
    // 校验x的dtype
    if (xDtype.has_value()) {
        TORCH_CHECK(SUPPORT_X_DTYPE_LIST.find(GetAclDataType(xDtype.value())) != SUPPORT_X_DTYPE_LIST.end(),
                    "The optional parameter xDtype only supports: "
                    "int8/hifloat8/float8_e4m3fn/float8_e5m2/float4_e1m2/float4_e2m1, but now is ",
                    xDtype.value());
    }

    TORCH_CHECK(SUPPORT_WORLD_SIZE_LIST.find(worldSize) != SUPPORT_WORLD_SIZE_LIST.end(), "The worldSize should be in ",
                c10::Join(", ", SUPPORT_WORLD_SIZE_LIST), ", but the actual value is ", worldSize);

    uint32_t AxisHIdx = (x.dim() == DIM_THREE ? 2 : 1);
    TORCH_CHECK(
        x.size(AxisHIdx) >= H_LOWER_LIMIT && x.size(AxisHIdx) <= H_UPPER_LIMIT && x.size(AxisHIdx) % NUM_128 == 0,
        "The x H-axis should be in [1024, 8192] and divisible by 128");

    int64_t axisBs = (x.dim() == DIM_THREE) ? x.size(DIM_ZERO) * x.size(DIM_ONE) : x.size(DIM_ZERO);
    TORCH_CHECK(axisBs % worldSize == 0, "The x BS-axis should be divisible by worldSize");

    // 校验scales的shape
    TORCH_CHECK(
        scales.dim() == DIM_ONE || scales.dim() == DIM_TWO || scales.dim() == DIM_THREE || scales.dim() == DIM_FOUR,
        "The input scales tensor shape is required to be equal to x in TG QuantMode, "
        "or be equal to x plus 1 in MX QuantMode, or be 1D (1) in PT QuantMode, "
        "but the actual input scales shape is ",
        scales.dim());

    // 校验scales是否为空tensor
    TORCH_CHECK(CheckTensorNotEmpty(scales), "The input tensor scales can not be empty tensor");
    if (scales.dim() == DIM_ONE) {
        TORCH_CHECK(scales.size(DIM_ZERO) == 1, "The input 1 dim tensor scales must be 1D (1)");
    }
    // 校验scales的dtype: float/float8_e8m0
    if (scalesDtype.has_value()) {
        TORCH_CHECK(
            SUPPORT_SCALES_DTYPE_LIST.find(GetAclDataType(scalesDtype.value())) != SUPPORT_SCALES_DTYPE_LIST.end(),
            "The optional parameter scalesDtype only supports float/float_e8m0, but now is ", scalesDtype.value());
    }

    // pta主要是为了推导output的shape和dtype，如果这里的output_dtype没有传入，则默认是bf16
    at::ScalarType outputDefaultDtype = at::kBFloat16;
    if (outputDtype.has_value()) {
        aclDataType outputAclDtype = GetAclDataType(outputDtype.value());
        if (outputAclDtype == ACL_FLOAT16) {
            outputDefaultDtype = at::kHalf;
        } else if (outputAclDtype == ACL_BF16) {
            outputDefaultDtype = at::kBFloat16;
        } else if (outputAclDtype == ACL_FLOAT) {
            outputDefaultDtype = at::kFloat;
        } else {
            TORCH_CHECK(false, "unsupported output dtype: ", static_cast<int32_t>(outputAclDtype));
        }
    }
    auto outputSize = {axisBs / worldSize, x.size(AxisHIdx)};
    at::Tensor outputTensor = at::empty(outputSize, x.options().dtype(outputDefaultDtype));

    // attr
    std::string reduceOpValueStr = std::string(reduceOp.value_or("sum"));
    char *reduceOpPtr = const_cast<char *>(reduceOpValueStr.c_str());

    // 如果是自定义的dtype的话，那么这里就需要使用一个wrapper
    // 让aclnn接口识别到传入的tensor具体的dtype类型，相当于打一个标签，标记真实的属性
    aclDataType xAclDtype = xDtype.has_value() ? GetAclDataType(xDtype.value()) : ConvertToAclDataType(x.scalar_type());
    aclDataType scalesAclDtype =
        scalesDtype.has_value() ? GetAclDataType(scalesDtype.value()) : ConvertToAclDataType(scales.scalar_type());
    TensorWrapper xWrapper = make_wrapper(x, xAclDtype);
    TensorWrapper scalesWrapper = make_wrapper(scales, scalesAclDtype);

    // 前面的wrapper打包传进去之后，这里直接调用aclnn接口
    ACLNN_CMD(aclnnQuantReduceScatter, context, xWrapper, scalesWrapper, hcclBufferSize, worldSize, reduceOpPtr,
              outputTensor);
    return outputTensor;
}

// Bind the C++ function to Python module
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
    m.def("npu_quant_reduce_scatter", &NpuQuantReduceScatter, "npu_quant_reduce_scatter");
}

} // namespace op_api
